import { useEffect, useMemo, useRef, useState } from "react"

type Screen = "launch" | "home" | "search" | "voice" | "menu" | "cart" | "checkout" | "summary" | "payment" | "confirm" | "orders" | "profile" | "settings"
type Theme = "light" | "dark" | "system"
type FulfillmentMethod = "Delivery" | "Pickup"
type ChatMessage = {
  from: "bot" | "user"
  text: string
}
type ComboSelection = {
  side: string
  drink: string
  size: string
  addOn: string
}
type IconProps = {
  name: string
  size?: number
}
type HeaderProps = {
  title?: string
  back?: Screen
}
type SpeechRecognitionInstance = {
  continuous: boolean
  interimResults: boolean
  lang: string
  start: () => void
  stop: () => void
  abort: () => void
  onstart: (() => void) | null
  onend: (() => void) | null
  onerror: ((event: { error: string }) => void) | null
  onresult: ((event: {
    results: ArrayLike<{ 0: { transcript: string } }>
  }) => void) | null
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance
    webkitAudioContext?: typeof AudioContext
  }
}

const photos = {
  chick:
    "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=1000&q=85",
  bowl: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=1000&q=85",
  tacos:
    "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?auto=format&fit=crop&w=1000&q=85",
  salad:
    "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1000&q=85",
  pizza:
    "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1400&q=85",
  fries: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=1000&q=85",
  southwestBowl: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1000&q=85",
  burger: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=85",
  cheeseburger: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1000&q=85",
  soda: "https://images.unsplash.com/photo-1581006852262-e4307cf6283a?auto=format&fit=crop&w=1000&q=85",
}

const restaurants = [
  {
    name: "Campus Chicken Co.",
    type: "Chicken • American",
    rating: 4.8,
    time: 18,
    price: "$",
    image: photos.chick,
    busy: "low",
    busyLabel: "Fast right now",
    pickupLocation: "210 University Drive",
    pickupInstructions: "Front counter",
  },
  {
    name: "Orange Bowl Kitchen",
    type: "Healthy • Bowls",
    rating: 4.7,
    time: 24,
    price: "$$",
    image: photos.bowl,
    busy: "medium",
    busyLabel: "Picking up",
    pickupLocation: "455 College Avenue",
    pickupInstructions: "Kitchen entrance",
  },
  {
    name: "Taco Study Hall",
    type: "Mexican • Tacos",
    rating: 4.6,
    time: 16,
    price: "$",
    image: photos.tacos,
    busy: "high",
    busyLabel: "Very popular",
    pickupLocation: "88 Student Union Lane",
    pickupInstructions: "Pickup window",
  },
  {
    name: "Late Night Pizza",
    type: "Pizza • Italian",
    rating: 4.5,
    time: 42,
    price: "$$",
    image: photos.pizza,
    busy: "busy",
    busyLabel: "Busy",
    pickupLocation: "300 Market Street",
    pickupInstructions: "Front counter",
  },
  {
    name: "Vol Burger House",
    type: "Burgers • American",
    rating: 4.7,
    time: 21,
    price: "$$",
    image: photos.burger,
    busy: "medium",
    busyLabel: "Moderately busy",
    pickupLocation: "1420 Volunteer Boulevard",
    pickupInstructions: "Order pickup shelf",
  },
]

const menu = [
  {
    id: 1,
    name: "Crispy Chicken Sandwich",
    desc: "Pickles, slaw, house sauce, brioche bun",
    price: 8.5,
    calories: 640,
    options: ["No pickles", "No slaw", "Extra sauce", "Add cheese"],
    image: photos.chick,
  },
  {
    id: 2,
    name: "Waffle Fries",
    desc: "Sea salt, crispy outside, fluffy inside",
    price: 3.75,
    calories: 420,
    options: ["Regular", "Large +$1.50", "Add cheese +$0.75"],
    image: photos.fries,
  },
  {
    id: 3,
    name: "Southwest Chicken Bowl",
    desc: "Rice, roasted corn, beans, avocado",
    price: 11.25,
    calories: 590,
    options: ["No avocado", "Extra chicken +$2.50", "No beans", "Add salsa"],
    image: photos.southwestBowl,
  },
  {
    id: 4,
    name: "Classic Cheeseburger",
    desc: "Angus beef, cheddar, lettuce, tomato, pickles, toasted bun",
    price: 9.5,
    calories: 720,
    options: ["No pickles", "No tomato", "No onions", "Add ketchup", "Extra cheese +$1", "Add bacon +$1.50"],
    image: photos.cheeseburger,
  },
  {
    id: 5,
    name: "Double Smash Burger",
    desc: "Two smashed beef patties, American cheese, grilled onions, house sauce",
    price: 12.5,
    calories: 890,
    options: ["No onions", "Add ketchup", "Extra patty +$3", "No sauce", "Add bacon +$1.50"],
    image: photos.burger,
  },
  {
    id: 6,
    name: "Burger Combo",
    desc: "Classic cheeseburger, regular fries, and a fountain drink",
    price: 13.5,
    calories: 1120,
    options: ["Cola", "Diet cola", "Lemon-lime", "Iced tea", "No onions", "Add ketchup", "Swap fries for side salad"],
    image: photos.burger,
  },
  {
    id: 7,
    name: "Chicken Sandwich Combo",
    desc: "Crispy chicken sandwich, waffle fries, and a fountain drink",
    price: 12.5,
    calories: 1060,
    options: ["Cola", "Diet cola", "Lemon-lime", "Iced tea", "No pickles", "Extra sauce"],
    image: photos.chick,
  },
]

type Restaurant = (typeof restaurants)[number]
type MenuItem = (typeof menu)[number]
type EtaRange = { start: number; end: number }

const getEtaRange = (restaurant: Restaurant, method: FulfillmentMethod): EtaRange =>
  method === "Delivery"
    ? { start: restaurant.time, end: restaurant.time + 8 }
    : {
        start: Math.max(8, restaurant.time - 6),
        end: Math.max(8, restaurant.time - 2),
      }

const formatEtaRange = (restaurant: Restaurant, method: FulfillmentMethod) => {
  const { start, end } = getEtaRange(restaurant, method)
  return `${start}–${end} min`
}

// Each restaurant owns its own menu. IDs stay unique so cart quantities never
// collide when customers move between restaurants.
const restaurantMenus: Record<string, typeof menu> = {
  "Campus Chicken Co.": [menu[0], menu[1], menu[2], menu[6]],
  "Orange Bowl Kitchen": [
    menu[2],
    { id: 14, name: "Avocado Garden Salad", desc: "Mixed greens, avocado, cucumber, tomato, citrus vinaigrette", price: 10.5, calories: 430, options: ["No cucumber", "Add grilled chicken +$2.50", "Dressing on side"], image: photos.salad },
    { id: 15, name: "Southwest Veggie Bowl", desc: "Brown rice, black beans, roasted corn, avocado, pico de gallo", price: 9.75, calories: 520, options: ["No avocado", "Extra beans", "Add grilled chicken +$2.50"], image: photos.southwestBowl },
  ],
  "Taco Study Hall": [
    { id: 16, name: "Street Taco Trio", desc: "Three soft tacos with cilantro, onion, and salsa", price: 10.25, calories: 610, options: ["Chicken", "Steak +$1.50", "Veggie", "Mild salsa", "Hot salsa"], image: photos.tacos },
    { id: 17, name: "Loaded Chicken Burrito", desc: "Grilled chicken, rice, beans, cheese, pico, and salsa", price: 11.5, calories: 790, options: ["No beans", "No cheese", "Extra salsa", "Add guacamole +$1.50"], image: photos.tacos },
    { id: 18, name: "Loaded Nachos", desc: "Tortilla chips, queso, black beans, pico, jalapeños", price: 8.75, calories: 680, options: ["No jalapeños", "Add chicken +$2.50", "Add guacamole +$1.50"], image: photos.fries },
  ],
  "Late Night Pizza": [
    { id: 19, name: "Classic Cheese Pizza", desc: "Stone-baked crust, tomato sauce, mozzarella", price: 12.99, calories: 280, options: ["Small", "Medium +$3", "Large +$6", "Extra cheese +$1.50"], image: photos.pizza },
    { id: 20, name: "Pepperoni Pizza", desc: "Mozzarella, tomato sauce, and pepperoni", price: 14.99, calories: 320, options: ["Small", "Medium +$3", "Large +$6", "Extra pepperoni +$1.50"], image: photos.pizza },
    { id: 21, name: "Garlic Knots", desc: "Warm baked knots tossed in garlic butter and herbs", price: 5.5, calories: 390, options: ["Marinara", "Ranch", "No parmesan"], image: photos.fries },
  ],
  "Vol Burger House": [menu[3], menu[4], menu[5], menu[1]],
}

const voiceSuggestions = [
  { item: menu[6], restaurantName: "Campus Chicken Co.", phrase: "chicken sandwich combo" },
  { item: menu[2], restaurantName: "Orange Bowl Kitchen", phrase: "southwest chicken bowl" },
  { item: restaurantMenus["Taco Study Hall"][0], restaurantName: "Taco Study Hall", phrase: "street taco trio" },
  { item: restaurantMenus["Late Night Pizza"][1], restaurantName: "Late Night Pizza", phrase: "pepperoni pizza" },
  { item: restaurantMenus["Orange Bowl Kitchen"][1], restaurantName: "Orange Bowl Kitchen", phrase: "avocado garden salad" },
  { item: menu[5], restaurantName: "Vol Burger House", phrase: "burger combo" },
]

const categoryItemIds: Record<string, number[]> = {
  Sandwiches: [1, 7], Sides: [2, 18, 21], Bowls: [3, 14, 15],
  Burgers: [4, 5], Combos: [6, 7], Pizza: [19, 20], Tacos: [16, 17, 18],
}

const categories = [
  { name: "Burgers", image: photos.burger },
  { name: "Pizza", image: photos.pizza },
  { name: "Chicken", image: photos.chick },
  { name: "Mexican", image: photos.tacos },
  { name: "Healthy", image: photos.bowl },
]

const isModifierOption = (option: string) =>
  /^(?:no\b|extra\b|add\b|dressing on side\b|swap\b)/i.test(option.trim())

const choiceOptions = (item: MenuItem) =>
  [6, 7].includes(item.id) ? [] : item.options.filter((option) => !isModifierOption(option))
const modifierOptions = (item: MenuItem) => item.options.filter(isModifierOption)
const normalizeSpeech = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\bjalopenos?\b/g, "jalapenos")

const comboDrinkOptions = ["Cola", "Diet cola", "Lemon-lime", "Iced tea", "Water"]
const getSpokenComboDrink = (spoken: string) => {
  if (/\b(?:diet\s+(?:cola|coke|soda))\b/.test(spoken)) return "Diet cola"
  if (/\b(?:lemon[- ]lime|sprite|7 ?up)\b/.test(spoken)) return "Lemon-lime"
  if (/\b(?:iced tea|ice tea|sweet tea|unsweetened tea|tea)\b/.test(spoken)) return "Iced tea"
  if (/\bwater\b/.test(spoken)) return "Water"
  if (/\b(?:cola|coke|pepsi)\b/.test(spoken)) return "Cola"
  return undefined
}

const isModifierMentioned = (option: string, spoken: string) => {
  const normalizedOption = normalizeSpeech(option)
  const match = /^(no|add|extra)\s+(.+?)(?:\s+\+\$[\d.]+)?$/i.exec(normalizedOption)
  if (!match) return spoken.includes(normalizedOption)

  const [, action, ingredient] = match
  const escapedIngredient = ingredient.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  const actionPattern = action.toLowerCase() === "no" ? "no" : "(?:add|extra|with)"
  return new RegExp(`\\b${actionPattern}\\s+${escapedIngredient}\\b`).test(spoken)
}

const es: Record<string, string> = {
  Home: "Inicio",
  Search: "Buscar",
  "Past Orders": "Pedidos",
  Profile: "Perfil",
  "What are you craving?": "¿Qué se te antoja?",
  "Voice Order": "Pedido por voz",
  "Popular near you": "Popular cerca de ti",
  Settings: "Configuración",
  Appearance: "Apariencia",
  Accessibility: "Accesibilidad",
  Language: "Idioma",
  "Ordering preferences": "Preferencias de pedido",
  Back: "Atrás",
}

function Icon({ name, size = 20 }: IconProps) {
  const paths: Record<string, React.ReactNode> = {
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    mic: (
      <>
        <rect x="9" y="3" width="6" height="12" rx="3" />
        <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    bag: (
      <>
        <path d="M6 8h12l1 13H5L6 8Z" />
        <path d="M9 9V6a3 3 0 0 1 6 0v3" />
      </>
    ),
    arrow: <path d="m9 18 6-6-6-6" />,
    back: <path d="m15 18-6-6 6-6" />,
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    tune: (
      <>
        <path d="M4 7h10M18 7h2M4 17h2M10 17h10" />
        <circle cx="16" cy="7" r="2" />
        <circle cx="8" cy="17" r="2" />
      </>
    ),
    home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v11h14V10M9 21v-7h6v7" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
  }
  return (
    <svg
      aria-hidden="true"
      className="icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function App() {
  const hasActiveOrder = () =>
    typeof window !== "undefined" &&
    window.localStorage.getItem("good-eats-active-order") === "true"
  const [screen, setScreen] = useState<Screen>(() =>
    hasActiveOrder() ? "confirm" : "launch",
  )
  const [selectedRestaurant, setSelectedRestaurant] = useState(restaurants[0])
  const [query, setQuery] = useState("")
  const [filter, setFilter] = useState("All")
  const [sort, setSort] = useState("Recommended")
  const [cart, setCart] = useState<Record<number, number>>({})
  const [menuCategory, setMenuCategory] = useState("Popular")
  const [customizations, setCustomizations] = useState<Record<number, string>>({})
  const [modifications, setModifications] = useState<Record<number, string[]>>({})
  const [comboEnabled, setComboEnabled] = useState<Record<number, boolean>>({})
  const [comboSelections, setComboSelections] = useState<Record<number, ComboSelection>>({})
  const [method, setMethod] = useState<FulfillmentMethod>("Delivery")
  const [time, setTime] = useState("ASAP")
  const [theme, setTheme] = useState<Theme>("light")
  const [textSize, setTextSize] = useState("medium")
  const [language, setLanguage] = useState("English")
  const [contrast, setContrast] = useState(false)
  const [reduced, setReduced] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [listening, setListening] = useState(false)
  const [voiceError, setVoiceError] = useState("")
  const [voiceOrderActive, setVoiceOrderActive] = useState(false)
  const [pendingComboDrinkItemId, setPendingComboDrinkItemId] = useState<number | null>(null)
  const [placed, setPlaced] = useState(hasActiveOrder)
  const [chatOpen, setChatOpen] = useState(false)
  const [chatInput, setChatInput] = useState("")
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      from: "bot",
      text: "Hi, I’m GE! I can help you find food, manage your order, or change accessibility settings.",
    },
  ])
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const screenHistoryRef = useRef<Screen[]>([])
  const t = (s: string) => (language === "Spanish" ? es[s] || s : s)
  const activeMenu = restaurantMenus[selectedRestaurant.name] || restaurantMenus["Campus Chicken Co."]
  const pendingComboItem = pendingComboDrinkItemId === null
    ? undefined
    : activeMenu.find((item) => item.id === pendingComboDrinkItemId)
  const pendingComboDrinkPrompt = pendingComboItem
    ? `What drink would you like with your ${pendingComboItem.name}?`
    : "What drink would you like with your combo?"
  const availableMenuCategories = ["Popular", ...Array.from(new Set(activeMenu.map((item) => {
    if ([1, 7].includes(item.id)) return "Sandwiches"
    if ([2, 18, 21].includes(item.id)) return "Sides"
    if ([3, 14, 15].includes(item.id)) return "Bowls"
    if ([4, 5].includes(item.id)) return "Burgers"
    if ([6, 7].includes(item.id)) return "Combos"
    if ([19, 20].includes(item.id)) return "Pizza"
    if ([16, 17].includes(item.id)) return "Tacos"
    return "Popular"
  }))).filter((category) => category !== "Popular")]
  const qty = Object.values(cart).reduce((a, b) => a + b, 0)
  const comboExtra = (selection?: ComboSelection) => {
    if (!selection) return 0
    return (selection.size === "Large" ? 1.5 : 0) +
      (selection.side === "Side salad" ? 1.25 : 0) +
      (selection.addOn === "Add bacon" ? 1.5 : selection.addOn === "Extra cheese" ? 1 : 0)
  }
  const comboDescription = (selection?: ComboSelection) => selection
    ? `${selection.size} · ${selection.side} · ${selection.drink || "Choose a drink"}${selection.addOn !== "No add-on" ? ` · ${selection.addOn}` : ""}`
    : "Regular · Fries · Cola · No add-on"
  const canUpgradeToCombo = (item: MenuItem) => [1, 4].includes(item.id)
  const isComboItem = (item: MenuItem) =>
    [6, 7].includes(item.id) || Boolean(comboEnabled[item.id])
  const comboUpgradePrice = (item: MenuItem) =>
    canUpgradeToCombo(item) && comboEnabled[item.id] ? 4 : 0
  const getComboSelection = (id: number): ComboSelection => comboSelections[id] || {
    side: "Fries", drink: "Cola", size: "Regular", addOn: "No add-on",
  }
  const updateCombo = (id: number, field: keyof ComboSelection, value: string) => {
    setComboSelections((current) => ({
      ...current,
      [id]: { ...getComboSelection(id), [field]: value },
    }))
    if (field === "drink" && pendingComboDrinkItemId === id) {
      setPendingComboDrinkItemId(null)
    }
  }
  const toggleModification = (id: number, option: string, checked: boolean) => {
    setModifications((current) => {
      const selected = current[id] || []
      return {
        ...current,
        [id]: checked
          ? [...new Set([...selected, option])]
          : selected.filter((item) => item !== option),
      }
    })
  }
  const customizationLabel = (item: MenuItem) => {
    const choice = customizations[item.id] || choiceOptions(item)[0]
    return [choice, ...(modifications[item.id] || [])].filter(Boolean).join(" · ") || "Standard"
  }
  const orderItemDescription = (item: MenuItem) =>
    isComboItem(item)
      ? [`Combo · ${comboDescription(getComboSelection(item.id))}`, ...(modifications[item.id] || [])].join(" · ")
      : customizationLabel(item)
  const optionExtra = (option?: string) => {
    const amount = /\+\$(\d+(?:\.\d{1,2})?)/.exec(option || "")?.[1]
    return amount ? Number(amount) : 0
  }
  const customizationExtra = (item: MenuItem) =>
    optionExtra(customizations[item.id] || choiceOptions(item)[0]) +
    (modifications[item.id] || []).reduce((sum, option) => sum + optionExtra(option), 0)
  const itemPrice = (item: MenuItem) =>
    item.price +
    customizationExtra(item) +
    comboUpgradePrice(item) +
    (isComboItem(item) ? comboExtra(comboSelections[item.id]) : 0)
  const ComboBuilder = ({ item }: { item: MenuItem }) => (
    <div className="combo-options" aria-label={`${item.name} combo options`}>
      <strong>Build your combo</strong>
      {comboUpgradePrice(item) > 0 && (
        <small>Combo upgrade: +${comboUpgradePrice(item).toFixed(2)}</small>
      )}
      <label className="customize-label">Side
        <select value={getComboSelection(item.id).side} onChange={(e) => updateCombo(item.id, "side", e.target.value)}>
          <option>Fries</option><option>Side salad</option><option>Fruit cup</option>
        </select>
      </label>
      <label className="customize-label">Drink
        <select value={getComboSelection(item.id).drink} onChange={(e) => updateCombo(item.id, "drink", e.target.value)}>
          {pendingComboDrinkItemId === item.id && <option value="" disabled>Choose a drink</option>}
          {comboDrinkOptions.map((drink) => <option key={drink}>{drink}</option>)}
        </select>
      </label>
      <label className="customize-label">Combo size
        <select value={getComboSelection(item.id).size} onChange={(e) => updateCombo(item.id, "size", e.target.value)}>
          <option>Regular</option><option>Large</option>
        </select>
      </label>
      <label className="customize-label">Add-on
        <select value={getComboSelection(item.id).addOn} onChange={(e) => updateCombo(item.id, "addOn", e.target.value)}>
          <option>No add-on</option><option>Extra cheese</option><option>Add bacon</option>
        </select>
      </label>
      <small>Combo options: +${comboExtra(comboSelections[item.id]).toFixed(2)}</small>
    </div>
  )
  const CustomizationFields = ({ item }: { item: MenuItem }) => (
    <>
      {canUpgradeToCombo(item) && (
        <label className="combo-toggle">
          <input
            type="checkbox"
            checked={Boolean(comboEnabled[item.id])}
            onChange={(event) => setComboEnabled((current) => ({ ...current, [item.id]: event.target.checked }))}
          />
          <span>Make it a combo <small>+$4.00</small></span>
        </label>
      )}
      {isComboItem(item) && <ComboBuilder item={item} />}
      {choiceOptions(item).length > 0 && (
        <label className="customize-label">Choose one
          <select
            value={customizations[item.id] || choiceOptions(item)[0]}
            onChange={(e) => setCustomizations((current) => ({ ...current, [item.id]: e.target.value }))}
          >
            {choiceOptions(item).map((option) => <option key={option}>{option}</option>)}
          </select>
        </label>
      )}
      {modifierOptions(item).length > 0 && (
        <fieldset className="modifier-options">
          <legend>Customize</legend>
          {modifierOptions(item).map((option) => (
            <label key={option}>
              <input
                type="checkbox"
                checked={(modifications[item.id] || []).includes(option)}
                onChange={(event) => toggleModification(item.id, option, event.target.checked)}
              />
              {option}
            </label>
          ))}
        </fieldset>
      )}
    </>
  )
  const subtotal = activeMenu.reduce(
    (sum, item) => sum + itemPrice(item) * (cart[item.id] || 0),
    0,
  )
  const total = subtotal + 3.49
  const playNavigationSound = () => {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext
    if (!AudioContextClass) return
    const context = audioContextRef.current || new AudioContextClass()
    audioContextRef.current = context
    if (context.state === "suspended") void context.resume()
    const oscillator = context.createOscillator()
    const gain = context.createGain()
    const now = context.currentTime
    oscillator.type = "sine"
    oscillator.frequency.setValueAtTime(520, now)
    oscillator.frequency.exponentialRampToValueAtTime(720, now + 0.075)
    gain.gain.setValueAtTime(0.0001, now)
    gain.gain.exponentialRampToValueAtTime(0.055, now + 0.012)
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11)
    oscillator.connect(gain)
    gain.connect(context.destination)
    oscillator.start(now)
    oscillator.stop(now + 0.12)
  }
  const go = (s: Screen) => {
    if (s === screen) return
    playNavigationSound()
    recognitionRef.current?.abort()
    screenHistoryRef.current.push(screen)
    setScreen(s)
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" })
  }
  const speakAssistant = (text: string) => {
    if (!window.speechSynthesis || typeof SpeechSynthesisUtterance === "undefined") return
    const locale = language === "Spanish" ? "es-US" : language === "French" ? "fr-FR" : "en-US"
    const synthesis = window.speechSynthesis
    synthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    const voices = synthesis.getVoices()
    utterance.voice =
      voices.find((voice) =>
        voice.lang.toLowerCase().startsWith(locale.slice(0, 2)) &&
        /zira|aria|jenny|samantha|victoria|ava|helena|julie|female/i.test(voice.name),
      ) ||
      voices.find((voice) => voice.lang.toLowerCase().startsWith(locale.slice(0, 2))) ||
      null
    utterance.lang = locale
    utterance.rate = 0.96
    utterance.pitch = 1.12
    synthesis.speak(utterance)
  }
  const openVoiceOrder = () => {
    setTranscript("")
    setVoiceError("")
    go("voice")
    speakAssistant(
      pendingComboDrinkItemId !== null
        ? pendingComboDrinkPrompt
        : voiceOrderActive
          ? "What else would you like to add?"
          : "Hi! How can I help you today?",
    )
  }
  const goBack = (fallback: Screen) => {
    playNavigationSound()
    recognitionRef.current?.abort()
    const previous = screenHistoryRef.current.pop() || fallback
    setScreen(previous)
    if (previous === "voice") {
      speakAssistant(
        pendingComboDrinkItemId !== null
          ? pendingComboDrinkPrompt
          : voiceOrderActive
            ? "What else would you like to add?"
            : "Hi! How can I help you today?",
      )
    }
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" })
  }
  const startVoiceOrder = () => {
    window.speechSynthesis?.cancel()
    if (listening) {
      recognitionRef.current?.stop()
      return
    }
    const Recognition =
      window.SpeechRecognition || window.webkitSpeechRecognition
    if (!Recognition) {
      setVoiceError(
        "Voice recognition is not supported in this browser. You can type your order below.",
      )
      return
    }
    recognitionRef.current?.abort()
    const recognition = new Recognition()
    recognitionRef.current = recognition
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang =
      language === "Spanish"
        ? "es-US"
        : language === "French"
          ? "fr-FR"
          : "en-US"
    recognition.onstart = () => {
      setVoiceError("")
      setTranscript("")
      setListening(true)
    }
    recognition.onresult = (event) => {
      const spoken = Array.from(
        event.results,
        (result) => result[0]?.transcript || "",
      )
        .join(" ")
        .trim()
      setTranscript(spoken)
    }
    recognition.onerror = (event) => {
      setListening(false)
      const errors: Record<string, string> = {
        "not-allowed":
          "Microphone access was blocked. Allow microphone access, then try again.",
        "audio-capture":
          "No microphone was found. Check your device audio settings.",
        "no-speech": "We didn’t hear anything. Tap the mic and try again.",
        network:
          "Your browser’s speech service couldn’t connect. Check your internet connection or type the order below.",
        "service-not-allowed":
          "Voice recognition is blocked by your browser. Allow microphone access or type your order below.",
      }
      setVoiceError(
        errors[event.error] ||
          "We couldn’t understand that. Please try again or type your order.",
      )
    }
    recognition.onend = () => setListening(false)
    try {
      recognition.start()
    } catch (error) {
      setListening(false)
      setVoiceError(
        error instanceof Error
          ? `Voice recognition couldn’t start: ${error.message}`
          : "Voice recognition couldn’t start. Check microphone access or type your order below.",
      )
    }
  }
  const voiceSearchTerm = (request: string) => {
    const spoken = request.toLowerCase()
    if (spoken.match(/chicken|sandwich|fries|burger/)) return "Chicken"
    if (spoken.match(/taco|mexican|burrito/)) return "Mexican"
    if (spoken.match(/healthy|salad|bowl/)) return "Healthy"
    if (spoken.match(/pizza|italian/)) return "Pizza"
    return request
      .trim()
      .replace(
        /\b(i|want|would|like|please|can|you|find|me|a|an|some|to|eat|order)\b/gi,
        " ",
      )
      .replace(/\s+/g, " ")
      .trim()
  }
  const findVoiceMatches = (request = transcript, preferredRestaurantName?: string) => {
    const spoken = normalizeSpeech(request.trim())
    if (!spoken) {
      setVoiceError("Tell us what you’re craving before finding matches.")
      return
    }

    if (pendingComboDrinkItemId !== null) {
      const drink = getSpokenComboDrink(spoken)
      if (!drink) {
        const message = `Which drink would you like: ${comboDrinkOptions.join(", ")}?`
        setVoiceError(message)
        speakAssistant(message)
        return
      }
      setComboSelections((current) => ({
        ...current,
        [pendingComboDrinkItemId]: {
          ...(current[pendingComboDrinkItemId] || {
            side: "Fries",
            drink: "",
            size: "Regular",
            addOn: "No add-on",
          }),
          drink,
        },
      }))
      setPendingComboDrinkItemId(null)
      setVoiceError("")
      setVoiceOrderActive(true)
      go("cart")
      speakAssistant(`Got it, ${drink}. Anything else?`)
      return
    }

    const requestedComboId = /\bcombos?\b/.test(spoken)
      ? /\b(?:chicken sandwich|chicken combo)\b/.test(spoken) &&
          !/\b(?:bowl|salad)\b/.test(spoken)
        ? 7
        : /\b(?:burger|cheeseburger)\b/.test(spoken)
          ? 6
          : undefined
      : undefined
    const itemRules: Array<[number, RegExp]> = [
      [7, /\bchicken sandwich combo\b/],
      [1, /\b(?:crispy )?chicken sandwich\b/],
      [2, /\b(?:waffle )?fries\b/],
      [3, /\b(?:southwest )?chicken bowl\b|\bbowl\b/],
      [14, /\b(?:garden )?salad\b/],
      [15, /\bveggie bowl\b/],
      [16, /\btacos?\b|\btaco trio\b/],
      [17, /\bburrito\b/],
      [18, /\bnachos?\b/],
      [20, /\bpepperoni pizza\b/],
      [19, /\bpizza\b/],
      [5, /\bdouble (?:smash )?burger\b/],
      [6, /\bburger combo\b/],
      [4, /\b(?:cheeseburger|burger)\b/],
      [21, /\bgarlic knots?\b/],
    ]
    const requestedIds = requestedComboId
      ? [requestedComboId]
      : [...new Set(itemRules.flatMap(([id, pattern]) => {
          if (!pattern.test(spoken)) return []
          if (id === 3 && /\bveggie\b/.test(spoken)) return []
          if (id === 19 && /\bpepperoni\b/.test(spoken)) return []
          if (id === 4 && /\bdouble\b/.test(spoken)) return []
          return [id]
        }))]
    const restaurantMatches = Object.entries(restaurantMenus)
      .map(([restaurantName, items]) => ({
        restaurantName,
        items,
        matches: requestedIds.filter((id) => items.some((item) => item.id === id)),
      }))
      .sort((a, b) =>
        b.matches.length - a.matches.length ||
        Number(b.restaurantName === preferredRestaurantName) -
          Number(a.restaurantName === preferredRestaurantName),
      )
    const selectedMatch = restaurantMatches[0]
    const requestedItems = new Map<number, { item: MenuItem; restaurantName: string }>()
    if (selectedMatch && selectedMatch.matches.length > 0) {
      for (const id of selectedMatch.matches) {
        const item = selectedMatch.items.find((candidate) => candidate.id === id)
        if (item) requestedItems.set(id, { item, restaurantName: selectedMatch.restaurantName })
      }
    }
    const mentionedModifiers = new Map<number, string[]>()
    for (const items of Object.values(restaurantMenus)) {
      for (const item of items) {
        const matched = modifierOptions(item).filter((option) =>
          isModifierMentioned(option, spoken),
        )
        if (matched.length) mentionedModifiers.set(item.id, matched)
      }
    }

    if (!requestedItems.size && mentionedModifiers.size) {
      const matchingCartItems = activeMenu.filter(
        (item) => cart[item.id] && mentionedModifiers.has(item.id),
      )
      if (matchingCartItems.length === 1) {
        const [item] = matchingCartItems
        const matches = mentionedModifiers.get(item.id) || []
        setModifications((current) => ({
          ...current,
          [item.id]: [...new Set([...(current[item.id] || []), ...matches])],
        }))
        setVoiceError("")
        setVoiceOrderActive(true)
        go("cart")
        speakAssistant(`I've updated your ${item.name}. Anything else?`)
        return
      }
      const message = matchingCartItems.length > 1
        ? `Which item should I update: ${matchingCartItems.map((item) => item.name).join(" or ")}?`
        : "Which item should I customize? Say its name too, like “burger with no onions.”"
      setVoiceError(message)
      speakAssistant(message)
      return
    }

    if (requestedItems.size) {
      const restaurantName = requestedItems.values().next().value?.restaurantName
      const restaurant = restaurants.find((candidate) => candidate.name === restaurantName)
      if (qty > 0 && restaurant && selectedRestaurant.name !== restaurant.name) {
        const message = `Your current order is from ${selectedRestaurant.name}. Finish that order before starting one from ${restaurant.name}.`
        setVoiceError(message)
        speakAssistant(message)
        return
      }
      if (restaurant) setSelectedRestaurant(restaurant)
      const nextModifications = [...requestedItems.keys()].reduce<Record<number, string[]>>((items, id) => {
        const matches = mentionedModifiers.get(id)
        if (matches) items[id] = matches
        return items
      }, {})
      const comboItem = [...requestedItems.values()].find(({ item }) => isComboItem(item))
      const spokenDrink = comboItem ? getSpokenComboDrink(spoken) : undefined
      setCart((current) => {
        const next = { ...current }
        for (const id of requestedItems.keys()) next[id] = (next[id] || 0) + 1
        return next
      })
      setModifications((current) => {
        const next = { ...current }
        for (const [id, options] of Object.entries(nextModifications)) {
          const itemId = Number(id)
          next[itemId] = [...new Set([...(current[itemId] || []), ...options])]
        }
        return next
      })
      if (comboItem) {
        setComboSelections((current) => ({
          ...current,
          [comboItem.item.id]: {
            ...(current[comboItem.item.id] || {
              side: "Fries",
              drink: "",
              size: "Regular",
              addOn: "No add-on",
            }),
            drink: spokenDrink || "",
          },
        }))
        setPendingComboDrinkItemId(spokenDrink ? null : comboItem.item.id)
      } else {
        setPendingComboDrinkItemId(null)
      }
      setVoiceOrderActive(true)
      setVoiceError("")
      go("cart")
      if (comboItem && !spokenDrink) {
        speakAssistant(`What drink would you like with your ${comboItem.item.name}?`)
      } else {
        const itemNames = [...requestedItems.values()].map(({ item }) => item.name)
        speakAssistant(
          `I've added ${itemNames.join(" and ")}${comboItem ? ` with ${spokenDrink}` : ""}. Anything else?`,
        )
      }
      return
    }

    if (/\bcombos?\b/.test(spoken)) {
      setVoiceError("I couldn’t find a matching combo for that item. Try a chicken sandwich combo or burger combo.")
      return
    }
    const term = voiceSearchTerm(request)
    setQuery(term)
    setFilter("All")
    go("search")
  }
  useEffect(() => () => recognitionRef.current?.abort(), [])
  const add = (id: number, amount = 1) =>
    setCart((c) => ({ ...c, [id]: Math.max(0, (c[id] || 0) + amount) }))
  const sendChat = (text = chatInput) => {
    const clean = text.trim()
    if (!clean) return
    const lower = clean.toLowerCase()
    const fastestRestaurant =
      restaurants
        .filter((restaurant) => restaurant.busy === "low")
        .sort((a, b) => a.time - b.time)[0] || restaurants[0]
    let reply =
      "I can help with food search, your cart, order tracking, or app settings. What would you like to do?"
    if (lower.includes("track") || lower.includes("order"))
      reply = placed
        ? "Your order is confirmed and the restaurant is preparing it now. Want me to open tracking?"
        : "You don’t have an active order yet. I can help you find something nearby."
    if (
      lower.includes("chicken") ||
      lower.includes("food") ||
      lower.includes("hungry")
    )
      reply =
        `Campus Chicken Co. is a student favorite. Delivery is estimated at ${formatEtaRange(restaurants[0], "Delivery")}; pickup is ${formatEtaRange(restaurants[0], "Pickup")}. I can show you the menu.`
    if (
      lower.includes("fast") ||
      lower.includes("busy") ||
      lower.includes("wait")
    )
      reply = `${fastestRestaurant.name} has the green Fast indicator. Delivery is estimated at ${formatEtaRange(fastestRestaurant, "Delivery")}; pickup is ${formatEtaRange(fastestRestaurant, "Pickup")}.`
    if (
      lower.includes("setting") ||
      lower.includes("dark") ||
      lower.includes("access")
    )
      reply =
        "You can change theme, text size, contrast, language, and reduced motion in Settings."
    setMessages((m) => [
      ...m,
      { from: "user", text: clean },
      { from: "bot", text: reply },
    ])
    setChatInput("")
  }
  const matches = useMemo(
    () =>
      restaurants
        .filter((r) => {
          const term = query.toLowerCase()
          return (
            (!term || `${r.name} ${r.type}`.toLowerCase().includes(term)) &&
            (filter === "All" ||
              r.type.includes(filter) ||
              (filter === "Fastest" && r.busy === "low"))
          )
        })
        .sort((a, b) => {
          if (sort === "Popular") return b.rating - a.rating
          const fastStatus = Number(b.busy === "low") - Number(a.busy === "low")
          if (fastStatus) return fastStatus
          if (sort === "Fastest") {
            return getEtaRange(a, method).start - getEtaRange(b, method).start
          }
          return 0
        }),
    [query, filter, sort, method],
  )
  const placeOrder = () => {
    setPlaced(true)
    setVoiceOrderActive(false)
    window.localStorage.setItem("good-eats-active-order", "true")
    go("confirm")
  }

  const Header = ({ title, back }: HeaderProps) => (
    <header className="subhead">
      {back ? (
        <button
          className="icon-btn"
          onClick={() => goBack(back)}
          aria-label={t("Back")}
        >
          <Icon name="back" />
        </button>
      ) : (
        <Logo />
      )}
      {title && <strong>{t(title)}</strong>}
      <button
        className="icon-btn"
        onClick={() => go("cart")}
        aria-label={`Cart, ${qty} items`}
      >
        <Icon name="bag" />
        {qty > 0 && <span className="badge">{qty}</span>}
      </button>
    </header>
  )

  const RestaurantCard = ({ r }: { r: typeof restaurants[number] }) => (
    <article
      className="restaurant-card"
      onClick={() => { setSelectedRestaurant(r); go("menu") }}
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") { setSelectedRestaurant(r); go("menu") } }}
    >
      <img src={r.image} alt={`${r.name} food`} onError={(event) => { event.currentTarget.onerror = null; event.currentTarget.src = photos.pizza }} />
      <div className="restaurant-copy">
        <div className="row between">
          <strong>{r.name}</strong>
          <span className="rating">★ {r.rating}</span>
        </div>
        <p>{r.type}</p>
        <div className={`busy-status ${r.busy}`}>
          <i />
          <strong>{r.busyLabel}</strong>
          <span>Live · updated now</span>
        </div>
        <div className="meta">
          <span>
            <Icon name="clock" size={16} /> Delivery {formatEtaRange(r, "Delivery")}
          </span>
          <span>{r.price} • Pickup {formatEtaRange(r, "Pickup")}</span>
        </div>
      </div>
    </article>
  )

  const BottomNav = () => (
    <nav className="bottom-nav" aria-label="Main navigation">
      {([
        ["search", "Search", "search"],
        ["orders", "Past Orders", "bag"],
        ["profile", "Profile", "user"],
      ] as const).map(([target, label, icon]) => (
        <button
          key={target}
          className={screen === target ? "active" : ""}
          onClick={() => go(target)}
        >
          <Icon name={icon} />
          <span>{t(label)}</span>
        </button>
      ))}
    </nav>
  )

  let content: React.ReactNode

  if (screen === "launch")
    content = (
      <main className="launch-screen">
        <span className="launch-orb launch-orb-one" />
        <span className="launch-orb launch-orb-two" />
        <span className="launch-orb launch-orb-three" />
        <div className="launch-top">
          <Logo />
          <button
            className="launch-profile"
            onClick={() => go("profile")}
            aria-label="Open profile"
          >
            <Icon name="user" />
          </button>
        </div>
        <div className="launch-copy">
          <span className="launch-kicker">GOOD FOOD, RIGHT NOW</span>
          <h1>Are you ready?</h1>
          <p>Choose how you want to start. We’ll keep it quick.</p>
        </div>
        <div className="launch-actions">
          <button onClick={() => go("home")}>
            <span>
              <Icon name="home" />
            </span>
            <strong>Browse</strong>
            <small>See what’s nearby</small>
          </button>
          <button onClick={openVoiceOrder}>
            <span>
              <Icon name="mic" />
            </span>
            <strong>Voice order</strong>
            <small>Tell GE what you want</small>
          </button>
          <button onClick={() => go("search")}>
            <span>
              <Icon name="search" />
            </span>
            <strong>Search</strong>
            <small>Find a specific meal</small>
          </button>
          <button onClick={() => go("orders")}>
            <span>
              <Icon name="bag" />
            </span>
            <strong>Recent</strong>
            <small>Reorder a favorite</small>
          </button>
        </div>
        <button className="launch-continue" onClick={() => go("home")}>
          Explore Good Eats <Icon name="arrow" />
        </button>
      </main>
    )
  else if (screen === "home")
    content = (
      <>
        <div className="home-head">
          <span className="hero-orb orb-one" />
          <span className="hero-orb orb-two" />
          <span className="hero-orb orb-three" />
          <div className="row between">
            <div className="row">
              <button
                className="startup-back"
                onClick={() => go("launch")}
                aria-label="Back to startup screen"
              >
                <Icon name="back" />
              </button>
              <Logo />
            </div>
            <button
              className="avatar"
              onClick={() => go("settings")}
              aria-label="Open settings"
            >
              <Icon name="user" />
            </button>
          </div>
          <p className="eyebrow">GOOD AFTERNOON, JORDAN</p>
          <h1>{t("What are you craving?")}</h1>
          <button className="location">
            <Icon name="pin" size={18} /> Off Campus <span>⌄</span>
          </button>
        </div>
        <main>
          <div className="search-row">
            <button className="search-box" onClick={() => go("search")}>
              <Icon name="search" /> Search restaurants or food
            </button>
            <button
              className="voice-square"
              onClick={openVoiceOrder}
              aria-label={t("Voice Order")}
            >
              <Icon name="mic" />
            </button>
          </div>
          <div className="live-guide" aria-label="Live restaurant busyness">
            <div>
              <span className="live-dot" /> <strong>Live busyness</strong>
            </div>
            <div className="busy-scale">
              <span className="low">Fast</span>
              <span className="medium">Steady</span>
              <span className="high">Popular</span>
              <span className="busy">Busy</span>
            </div>
          </div>
          <div className="food-chips">
            {categories.map((x) => (
              <button
                onClick={() => {
                  setQuery(x.name)
                  go("search")
                }}
                key={x.name}
              >
                <img src={x.image} alt="" />
                <span>{x.name}</span>
              </button>
            ))}
          </div>
          <section>
            <div className="section-title">
              <div>
                <span className="kicker">BACK FOR MORE?</span>
                <h2>Recent order</h2>
              </div>
              <button onClick={() => go("orders")}>View all</button>
            </div>
            <article className="recent">
              <img src={photos.chick} alt="" />
              <div>
                <strong>Campus Chicken Co.</strong>
                <p>Chicken sandwich, waffle fries</p>
                <button onClick={() => go("menu")}>Reorder · $15.74</button>
              </div>
            </article>
          </section>
          <section>
            <div className="section-title">
              <div>
                <span className="kicker">CURATED FOR YOU</span>
                <h2>{t("Popular near you")}</h2>
              </div>
              <button onClick={() => go("search")}>See all</button>
            </div>
            <div className="card-grid">
              {restaurants.slice(0, 2).map((r) => (
                <RestaurantCard r={r} key={r.name} />
              ))}
            </div>
          </section>
        </main>
        <BottomNav />
      </>
    )
  else if (screen === "search")
    content = (
      <>
        <Header title="Find your next meal" back="home" />
        <main>
          <div className="search-input">
            <Icon name="search" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Restaurant, dish, or cuisine"
            />
            <button onClick={openVoiceOrder} aria-label="Voice search">
              <Icon name="mic" />
            </button>
          </div>
          <div className="chips filter-chips">
            {["All", "Fastest", "Chicken", "Healthy"].map((x) => (
              <button
                className={filter === x ? "selected" : ""}
                onClick={() => setFilter(x)}
                key={x}
              >
                {x}
              </button>
            ))}
          </div>
          <div className="discovery-bar">
            <div>
              <span className="kicker">DISCOVER</span>
              <strong>Popular & recommended</strong>
            </div>
            <label>
              Sort by
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option>Recommended</option>
                <option>Popular</option>
                <option>Fastest</option>
              </select>
            </label>
          </div>
          <div className="food-peeks">
            {menu.map((item) => (
              <button key={item.id} onClick={() => { setSelectedRestaurant(restaurants[0]); go("menu") }}>
                <img src={item.image} alt="" />
                <span>{item.name.split(" ").slice(0, 2).join(" ")}</span>
              </button>
            ))}
          </div>
          <div className="result-heading">
            <div>
              <strong>{matches.length} places nearby</strong>
              <span className="live-update">
                <i /> Live wait times
              </span>
            </div>
            <button>
              <Icon name="tune" size={17} /> Filters
            </button>
          </div>
          <div className="list">
            {matches.map((r) => (
              <RestaurantCard r={r} key={r.name} />
            ))}
          </div>
          {!matches.length && (
            <div className="empty">
              <span>0 results</span>
              <h2>No bites found</h2>
              <p>Try a different food or clear your filters.</p>
              <button
                className="primary"
                onClick={() => {
                  setQuery("")
                  setFilter("All")
                }}
              >
                Clear search
              </button>
            </div>
          )}
        </main>
        <BottomNav />
      </>
    )
  else if (screen === "voice")
    content = (
      <>
        <Header title="Voice order" back="launch" />
        <main className="voice-page">
          <span className="kicker">HANDS-FREE ORDERING</span>
          <div className="voice-assistant-prompt" aria-live="polite">
            <BrandMark small />
            <strong>
              {pendingComboDrinkItemId !== null
                ? pendingComboDrinkPrompt
                : voiceOrderActive
                  ? "What else would you like to add?"
                  : "Hi! How can I help you today?"}
            </strong>
          </div>
          <h1>{pendingComboDrinkItemId !== null ? "Choose your combo drink" : "What would you like to eat?"}</h1>
          <p>
            {pendingComboDrinkItemId !== null
              ? `Say or type ${comboDrinkOptions.join(", ")}.`
              : "Say an item, a combo, or a few foods together. For example, “a chicken sandwich combo with no pickles.” You can also type your order below."}
          </p>
          <button
            className={`mic-orb ${listening ? "listening" : ""}`}
            onClick={startVoiceOrder}
            aria-pressed={listening}
            aria-label={listening ? "Stop recording" : "Start voice order"}
          >
            <Icon name="mic" size={36} />
          </button>
          <strong className="listen-label" aria-live="polite">
            {listening
              ? "Listening… tap to stop"
              : transcript
                ? "Ready to find your food"
                : "Tap the mic to start"}
          </strong>
          {voiceError && (
            <div className="voice-error" role="alert">
              {voiceError}
            </div>
          )}
          <label className="transcript">
            <span>What we heard</span>
            <textarea
              value={transcript}
              onChange={(e) => {
                setTranscript(e.target.value)
                setVoiceError("")
              }}
              placeholder="Your spoken order will appear here. You can also type it."
            />
          </label>
          <div className="voice-recommendations">
            <div className="row between">
              <div>
                <span className="kicker">SMART MATCHES</span>
                <h3>Popular picks to get started</h3>
              </div>
              <span className="live-update">
                <i /> Live
              </span>
            </div>
            <div className="voice-suggestion-grid">
              {voiceSuggestions.map(({ item, restaurantName, phrase }) => (
                <button
                  key={`${restaurantName}-${item.id}`}
                  onClick={() => {
                    setTranscript(phrase)
                    findVoiceMatches(phrase, restaurantName)
                  }}
                >
                  <img src={item.image} alt="" />
                  <span>
                    <strong>{item.name}</strong>
                    <small>
                      {restaurantName} · {formatEtaRange(
                        restaurants.find((restaurant) => restaurant.name === restaurantName) || restaurants[0],
                        "Delivery",
                      )}
                    </small>
                  </span>
                  <b>Order</b>
                </button>
              ))}
            </div>
          </div>
          <div className="action-stack">
            <button
              className="primary"
              onClick={() => findVoiceMatches()}
              disabled={!transcript.trim()}
            >
              Find matches <Icon name="arrow" />
            </button>
            <button className="secondary" onClick={startVoiceOrder}>
              {listening ? "Stop listening" : "Repeat voice input"}
            </button>
          </div>
        </main>
      </>
    )
  else if (screen === "menu")
    content = (
      <>
        <Header back="search" />
        <div className="restaurant-hero">
          <img
            src={selectedRestaurant.image}
            alt={`${selectedRestaurant.name} restaurant food`}
            onError={(event) => {
              event.currentTarget.onerror = null
              event.currentTarget.src = photos.pizza
            }}
          />
          <div>
            <span className="rating">★ 4.8 · 1.2k ratings</span>
            <h1>{selectedRestaurant.name}</h1>
            <p>
              Delivery {formatEtaRange(selectedRestaurant, "Delivery")} · Pickup{" "}
              {formatEtaRange(selectedRestaurant, "Pickup")} · $0 delivery fee
            </p>
          </div>
        </div>
        <main>
          <div className="chips">
            {availableMenuCategories.map((category) => (
              <button className={menuCategory === category ? "selected" : ""} onClick={() => setMenuCategory(category)} key={category}>{category}</button>
            ))}
          </div>
          <div className="menu-list">
            {activeMenu.filter((item) => menuCategory === "Popular" || (categoryItemIds[menuCategory] || []).includes(item.id)).map((item) => (
              <article className="menu-item" key={item.id}>
                <div>
                  <span className="kicker">
                    {item.id === 1 ? "#1 MOST LOVED" : "STUDENT FAVORITE"}
                  </span>
                  <h3>{item.name}</h3>
                  <p>{item.desc}</p>
                  <p className="calorie-line">Approx. {item.calories} calories per serving</p>
                  <CustomizationFields item={item} />
                  <strong>${itemPrice(item).toFixed(2)}</strong>
                  {cart[item.id] ? (
                    <div className="stepper">
                      <button onClick={() => add(item.id, -1)}>−</button>
                      <span>{cart[item.id]}</span>
                      <button onClick={() => add(item.id)}>+</button>
                    </div>
                  ) : (
                    <button className="add" onClick={() => add(item.id)}>
                      Add +
                    </button>
                  )}
                </div>
                <img src={item.image || photos.burger} alt={item.name} loading="lazy" onError={(event) => { event.currentTarget.onerror = null; event.currentTarget.src = photos.burger }} />
              </article>
            ))}
          </div>
        </main>
        {qty > 0 && (
          <button className="cart-bar" onClick={() => go("cart")}>
            <span className="cart-count">{qty}</span>
            <strong>View cart</strong>
            <span>${subtotal.toFixed(2)}</span>
          </button>
        )}
      </>
    )
  else if (screen === "cart")
    content = (
      <>
        <Header title="Your order" back="menu" />
        <main>
          <section className="order-source panel">
            <div className="order-source-restaurant">
              <img src={selectedRestaurant.image} alt="" />
              <div>
                <span className="kicker">ORDER FROM</span>
                <strong>{selectedRestaurant.name}</strong>
                <small>{selectedRestaurant.type}</small>
              </div>
            </div>
            <div className="order-source-details">
              <span>{method} · Est. {formatEtaRange(selectedRestaurant, method)}</span>
              <span>
                {method === "Delivery"
                  ? "1428 College Avenue, Apt 3B"
                  : selectedRestaurant.pickupLocation}
              </span>
            </div>
          </section>
          {voiceOrderActive && (
            <div className="anything-else-prompt" aria-live="polite">
              <BrandMark small />
              <div>
                <strong>
                  {pendingComboDrinkItemId !== null
                    ? pendingComboDrinkPrompt
                    : "Anything else?"}
                </strong>
                <span>
                  {pendingComboDrinkItemId !== null
                    ? "Choose a drink before continuing to checkout."
                    : "Add another item by voice, or continue to checkout."}
                </span>
              </div>
            </div>
          )}
          <div className="cart-list">
            {activeMenu
              .filter((i) => cart[i.id])
              .map((i) => (
                <article key={i.id} className="cart-item">
                  <img src={i.image || photos.burger} alt={i.name} onError={(event) => { event.currentTarget.onerror = null; event.currentTarget.src = photos.burger }} />
                  <div>
                    <strong>{i.name}</strong>
                    <p>{orderItemDescription(i)}</p>
                    <p>Approx. {i.calories} cal</p>
                    <p>${itemPrice(i).toFixed(2)} each</p>
                    <CustomizationFields item={i} />
                  </div>
                  <div className="stepper">
                    <button onClick={() => add(i.id, -1)}>−</button>
                    <span>{cart[i.id]}</span>
                    <button onClick={() => add(i.id)}>+</button>
                  </div>
                </article>
              ))}
          </div>
          <button
            className="text-button"
            onClick={() => voiceOrderActive ? openVoiceOrder() : go("menu")}
          >
            + {pendingComboDrinkItemId !== null
              ? "Choose combo drink by voice"
              : voiceOrderActive
                ? "Add another by voice"
                : "Add another item"}
          </button>
          <div className="totals">
            <div>
              <span>Subtotal</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <div>
              <span>Estimated fees</span>
              <strong>$3.49</strong>
            </div>
            <div className="total">
              <span>Estimated total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>
          </div>
          <button
            className="primary full"
            disabled={!qty || pendingComboDrinkItemId !== null}
            onClick={() => go("checkout")}
          >
            Continue to checkout <Icon name="arrow" />
          </button>
        </main>
      </>
    )
  else if (screen === "checkout")
    content = (
      <>
        <Header title="When & where" back="cart" />
        <main>
          <div className="segmented">
            <button
              className={method === "Delivery" ? "selected" : ""}
              onClick={() => setMethod("Delivery")}
            >
              Delivery
            </button>
            <button
              className={method === "Pickup" ? "selected" : ""}
              onClick={() => setMethod("Pickup")}
            >
              Pickup
            </button>
          </div>
          <section className="panel">
            <span className="kicker">
              {method === "Delivery" ? "DELIVER TO" : "PICK UP AT"}
            </span>
            <h2>
              {method === "Delivery"
                ? "1428 College Avenue, Apt 3B"
                : selectedRestaurant.pickupLocation}
            </h2>
            <p>
              {method === "Delivery"
                ? "Off Campus · Leave at door"
                : `${selectedRestaurant.name} · ${selectedRestaurant.pickupInstructions}`}
            </p>
            <button className="text-button">Edit</button>
          </section>
          <section>
            <span className="kicker">CHOOSE A {method.toUpperCase()} TIME</span>
            <div className="time-grid">
              {["ASAP", "8:00 PM", "9:00 PM", "10:00 PM"].map((x) => (
                <button
                  className={time === x ? "selected" : ""}
                  onClick={() => setTime(x)}
                  key={x}
                >
                  <strong>{x}</strong>
                  <span>
                    {x === "ASAP"
                      ? `Est. ${formatEtaRange(selectedRestaurant, method)}`
                      : `Scheduled ${method.toLowerCase()}`}
                  </span>
                </button>
              ))}
            </div>
          </section>
          <section className="order-preview panel">
            <div className="row between">
              <div>
                <span className="kicker">ORDER SUMMARY</span>
                <strong>{selectedRestaurant.name}</strong>
              </div>
              <strong>{qty} {qty === 1 ? "item" : "items"}</strong>
            </div>
            <ul>
              {activeMenu.filter((item) => cart[item.id]).map((item) => (
                <li key={item.id}>
                  <span>{cart[item.id]} × {item.name}<small>{orderItemDescription(item)}</small></span>
                  <strong>${(itemPrice(item) * cart[item.id]).toFixed(2)}</strong>
                </li>
              ))}
            </ul>
            <div className="row between order-preview-total">
              <span>Estimated total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>
          </section>
          <button className="primary full" onClick={() => go("summary")}>
            Review order <Icon name="arrow" />
          </button>
        </main>
      </>
    )
  else if (screen === "summary")
    content = (
      <>
        <Header title="Review order" back="checkout" />
        <main>
          <div className="receipt-head">
            <span className="kicker">{selectedRestaurant.name.toUpperCase()}</span>
            <h1>One last look.</h1>
            <p>
              {method} · {time}
            </p>
          </div>
          <div className="summary-items">
            {activeMenu
              .filter((i) => cart[i.id])
              .map((i) => (
                <article className="summary-edit-item" key={i.id}>
                  <div className="summary-edit-copy">
                    <strong>{i.name}</strong>
                    <small>{orderItemDescription(i)} · Approx. {i.calories} cal</small>
                    <CustomizationFields item={i} />
                    <div className="stepper">
                      <button aria-label={`Remove one ${i.name}`} onClick={() => add(i.id, -1)}>−</button>
                      <span>{cart[i.id]}</span>
                      <button aria-label={`Add one ${i.name}`} onClick={() => add(i.id, 1)}>+</button>
                    </div>
                  </div>
                  <strong>${(itemPrice(i) * cart[i.id]).toFixed(2)}</strong>
                </article>
              ))}
            <button className="text-button" onClick={() => go("menu")}>+ Add more food</button>
          </div>
          <div className="panel compact">
            <div className="row between">
              <span>
                <Icon name="pin" />{" "}
                {method === "Delivery"
                  ? "1428 College Avenue"
                  : selectedRestaurant.pickupLocation}
              </span>
              <button className="text-button" onClick={() => go("checkout")}>
                Change
              </button>
            </div>
          </div>
          <div className="totals">
            <div>
              <span>Subtotal</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <div>
              <span>Fees</span>
              <strong>$3.49</strong>
            </div>
            <div className="total">
              <span>Total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>
          </div>
          <button className="primary full" onClick={() => go("payment")}>
            Confirm and pay
          </button>
        </main>
      </>
    )
  else if (screen === "payment")
    content = (
      <>
        <Header title="Payment" back="summary" />
        <main>
          <div className="payment-card">
            <span>GOOD EATS STUDENT CARD</span>
            <strong>•••• •••• •••• 4242</strong>
            <div>
              <span>JORDAN LEE</span>
              <span>08/28</span>
            </div>
          </div>
          <div className="panel">
            <span className="kicker">PAYMENT METHOD</span>
            <div className="row between">
              <strong>Visa ending in 4242</strong>
              <button className="text-button">Change</button>
            </div>
          </div>
          <div className="pay-total">
            <span>Total due</span>
            <strong>${total.toFixed(2)}</strong>
          </div>
          <p className="fine">
            This is a prototype. No real payment will be processed.
          </p>
          <button className="primary full" onClick={placeOrder}>
            Pay ${total.toFixed(2)}
          </button>
        </main>
      </>
    )
  else if (screen === "confirm")
    content = (
      <>
        <main className="confirmation">
          <div className="success-mark">
            <Icon name="check" size={34} />
          </div>
          <span className="kicker">ORDER #GE-2418</span>
          <h1>Order placed!</h1>
          <p>{selectedRestaurant.name} is getting started.</p>
          <div className="eta">
            <span>
              Estimated {method === "Delivery" ? "arrival" : "pickup"}
            </span>
            <strong>
              {time === "ASAP"
                ? formatEtaRange(selectedRestaurant, method)
                : `${time} scheduled`}
            </strong>
          </div>
          <div className="panel queue-panel">
            <span className="kicker">ORDER LINE</span>
            <h2>3 orders ahead of you</h2>
            <p>Estimated kitchen queue: about 9–12 minutes before your order is ready to leave the restaurant.</p>
            <div className="queue-track"><span style={{width:"42%"}} /></div>
            <small>Demo queue estimate · updates are simulated in this prototype</small>
          </div>
          <div className="tracker">
            {["Ordered", "Cooking", "Ready"].map((x, i) => (
              <div className={i === 0 ? "done" : ""} key={x}>
                <span>{i === 0 ? <Icon name="check" size={16} /> : i + 1}</span>
                <strong>{x}</strong>
              </div>
            ))}
          </div>
          <div className="panel">
            <span className="kicker">{method.toUpperCase()}</span>
            <h3>
              {method === "Delivery"
                ? "1428 College Avenue, Apt 3B"
                : selectedRestaurant.pickupLocation}
            </h3>
          </div>
          <button className="secondary full">View receipt</button>
          <button className="secondary full" onClick={() => { setCart({}); setCustomizations({}); setModifications({}); setComboEnabled({}); setComboSelections({}); setVoiceOrderActive(false); setPendingComboDrinkItemId(null); setPlaced(false); window.localStorage.removeItem("good-eats-active-order"); go("home") }}>
            Start a new order
          </button>
          <button className="primary full" onClick={() => go("home")}>
            Back to home
          </button>
        </main>
      </>
    )
  else if (screen === "orders")
    content = (
      <>
        <Header title="Past Orders" back="home" />
        <main>
          <div className="receipt-head">
            <span className="kicker">YOUR ORDER HISTORY</span>
            <h1>
              Same favorites,
              <br />
              one tap away.
            </h1>
          </div>
          {(placed ? [1, 2] : [1]).map((_, i) => (
            <article className="order-card" key={i}>
              <div className="row between">
                <span className="status">
                  {i === 0 && placed ? "IN PROGRESS" : "DELIVERED"}
                </span>
                <span>{i === 0 && placed ? "Today" : "Mar 18"}</span>
              </div>
              <h3>Campus Chicken Co.</h3>
              <p>Chicken sandwich, waffle fries · ${total.toFixed(2)}</p>
              <button
                onClick={() => { if (!(i === 0 && placed)) { setCart({}); setCustomizations({}); setModifications({}); setComboEnabled({}); setComboSelections({}); setVoiceOrderActive(false); setPendingComboDrinkItemId(null); } go(i === 0 && placed ? "confirm" : "menu") }}
              >
                {i === 0 && placed ? "Track order" : "Order again"}{" "}
                <Icon name="arrow" size={17} />
              </button>
            </article>
          ))}
        </main>
        <BottomNav />
      </>
    )
  else if (screen === "profile")
    content = (
      <>
        <Header title="Profile" back="home" />
        <main>
          <div className="profile-block">
            <div className="big-avatar">JL</div>
            <h1>Jordan Lee</h1>
            <p>jordan@university.edu</p>
          </div>
          <div className="settings-list">
            {[
              ["settings", "Settings", "Appearance, accessibility & more"],
              ["orders", "Past Orders", "Receipts and reordering"],
            ].map(([to, name, desc]) => (
              <button key={to} onClick={() => go(to as Screen)}>
                <div>
                  <strong>{name}</strong>
                  <span>{desc}</span>
                </div>
                <Icon name="arrow" />
              </button>
            ))}
          </div>
        </main>
        <BottomNav />
      </>
    )
  else
    content = (
      <>
        <Header title="Settings" back="profile" />
        <main className="settings-page">
          <SettingsSection title="Appearance">
            <OptionRow label="Theme">
              <div className="mini-select">
                {(["light", "dark", "system"] as Theme[]).map((x) => (
                  <button
                    className={theme === x ? "selected" : ""}
                    onClick={() => setTheme(x)}
                    key={x}
                  >
                    {x[0].toUpperCase() + x.slice(1)}
                  </button>
                ))}
              </div>
            </OptionRow>
          </SettingsSection>
          <SettingsSection title="Accessibility">
            <div className="preview" data-size={textSize}>
              Your food, your way.
            </div>
            <OptionRow label="Text size">
              <div className="mini-select">
                {["small", "medium", "large"].map((x) => (
                  <button
                    className={textSize === x ? "selected" : ""}
                    onClick={() => setTextSize(x)}
                    key={x}
                  >
                    {x[0].toUpperCase() + x.slice(1)}
                  </button>
                ))}
              </div>
            </OptionRow>
            <Toggle
              label="Increase contrast"
              value={contrast}
              set={setContrast}
            />
            <Toggle label="Reduced motion" value={reduced} set={setReduced} />
          </SettingsSection>
          <SettingsSection title="Language">
            <OptionRow label="App language">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                <option>English</option>
                <option>Spanish</option>
                <option>French</option>
              </select>
            </OptionRow>
          </SettingsSection>
          <SettingsSection title="Ordering preferences">
            <OptionRow label="Default method">
              <div className="mini-select">
                <button
                  className={method === "Delivery" ? "selected" : ""}
                  onClick={() => setMethod("Delivery")}
                >
                  Delivery
                </button>
                <button
                  className={method === "Pickup" ? "selected" : ""}
                  onClick={() => setMethod("Pickup")}
                >
                  Pickup
                </button>
              </div>
            </OptionRow>
            <Toggle label="Prefer voice ordering" value={true} set={() => {}} />
            <Toggle label="Order notifications" value={true} set={() => {}} />
          </SettingsSection>
          <SettingsSection title="Account">
            {[
              "Profile information",
              "Past Orders",
              "Help & Support",
              "About Good Eats",
            ].map((x) => (
              <button className="link-row" key={x}>
                {x}
                <Icon name="arrow" />
              </button>
            ))}
          </SettingsSection>
        </main>
      </>
    )

  return (
    <div
      className={`app screen-${screen} theme-${theme} text-${textSize} ${
        contrast ? "high-contrast" : ""
      } ${reduced ? "reduced" : ""}`}
    >
      <div className="shell">
        {content}
        <ChatBot
          open={chatOpen}
          setOpen={setChatOpen}
          input={chatInput}
          setInput={setChatInput}
          messages={messages}
          send={sendChat}
          go={go}
          placed={placed}
        />
      </div>
    </div>
  )
}

function BrandMark({ small = false }: { small?: boolean }) {
  return (
    <span className={`brand-mark ${small ? "small" : ""}`} aria-hidden="true" />
  )
}
function Logo() {
  return (
    <div className="logo">
      <BrandMark />
      <strong>GOOD EATS</strong>
    </div>
  )
}
function ChatBot({
  open,
  setOpen,
  input,
  setInput,
  messages,
  send,
  go,
  placed,
}: {
  open: boolean
  setOpen: (v: boolean) => void
  input: string
  setInput: (v: string) => void
  messages: ChatMessage[]
  send: (text?: string) => void
  go: (s: Screen) => void
  placed: boolean
}) {
  return (
    <>
      {open && (
        <div className="chat-overlay">
          <aside className="chat-panel" aria-label="Good Eats help chat">
            <div className="chat-head">
              <div className="chat-identity">
                <BrandMark small />
                <div>
                  <strong>GE Help Bot</strong>
                  <span>
                    <i /> Online now
                  </span>
                </div>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close chatbot">
                ×
              </button>
            </div>
            <div className="chat-content">
              <div className="chat-intro">
                <span className="kicker">FAST, PRECISE HELP</span>
                <h2>What can GE help with?</h2>
                <p>
                  Ask about live wait times, your order, or the fastest food
                  nearby.
                </p>
              </div>
              <div className="chat-messages" aria-live="polite">
                {messages.map((message, i) => (
                  <div
                    className={`chat-message ${message.from}`}
                    key={`${message.text}-${i}`}
                  >
                    {message.from === "bot" && <BrandMark small />}
                    <p>{message.text}</p>
                  </div>
                ))}
              </div>
              <div className="quick-replies">
                <button
                  onClick={() => {
                    setOpen(false)
                    go("search")
                  }}
                >
                  Find food
                </button>
                <button
                  onClick={() => {
                    setOpen(false)
                    go(placed ? "confirm" : "orders")
                  }}
                >
                  {placed ? "Track order" : "Past orders"}
                </button>
                <button onClick={() => send("What is fastest right now?")}>
                  Fastest right now
                </button>
                <button
                  onClick={() => {
                    setOpen(false)
                    go("settings")
                  }}
                >
                  Settings
                </button>
              </div>
              <form
                className="chat-compose"
                onSubmit={(e) => {
                  e.preventDefault()
                  send()
                }}
              >
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask GE for help…"
                  aria-label="Message GE help bot"
                  autoFocus
                />
                <button type="submit" aria-label="Send message">
                  <Icon name="arrow" />
                </button>
              </form>
            </div>
          </aside>
        </div>
      )}
      <button
        className={`chat-launcher ${open ? "open" : ""}`}
        onClick={() => setOpen(!open)}
        aria-label={open ? "Close GE help bot" : "Open GE help bot"}
      >
        {open ? (
          <span className="chat-close">×</span>
        ) : (
          <>
            <BrandMark />
            <span className="chat-pulse" />
          </>
        )}
      </button>
    </>
  )
}
function SettingsSection({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <section className="setting-section">
      <span className="kicker">{title.toUpperCase()}</span>
      <div className="setting-card">{children}</div>
    </section>
  )
}
function OptionRow({
  label,
  children,
}: {
  label: string
  children: React.ReactNode
}) {
  return (
    <div className="option-row">
      <strong>{label}</strong>
      {children}
    </div>
  )
}
function Toggle({
  label,
  value,
  set,
}: {
  label: string
  value: boolean
  set: (v: boolean) => void
}) {
  return (
    <button className="toggle-row" onClick={() => set(!value)}>
      <strong>{label}</strong>
      <span className={`toggle ${value ? "on" : ""}`}>
        <i />
      </span>
    </button>
  )
}

export default App
